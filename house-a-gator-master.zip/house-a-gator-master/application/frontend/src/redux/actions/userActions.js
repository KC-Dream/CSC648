export const setIsLoggedIn=isLoggedIn =>({
  type: 'USER_SET_IS_LOGGED_IN',
  isLoggedIn,
});

