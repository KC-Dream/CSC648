export const setListingID= listingID =>({
    type: 'PRODUCT_SET_LISTING_ID',
    listingID,
});